<?php
	if ( ! defined( 'ABSPATH' ) ) 
		exit('No Such File');
	
	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	
// Role Management
		
	$wp_roles = new WP_Roles();
	$wp_roles->remove_role('teacher');
    $wp_roles->remove_role('student');
	$wp_roles->remove_role('parent');  
	$wp_roles->add_role('subscriber', __('Subscriber' ));
	$wp_roles->add_role('editor',__('editor' ));
	$wp_roles->add_role('contributor',__('contributor'));
	$wp_roles->add_role('author',__('author'));
	$wp_roles->add_role('client',__('client'));
	
	?>